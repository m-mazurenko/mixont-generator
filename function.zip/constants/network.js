const NETWORK = {
  eth: "eth",
  sol: "sol",
};

export {
  NETWORK,
};
